package com.pagani.analiseCredito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnaliseCreditoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnaliseCreditoApplication.class, args);
	}

}
