package com.pagani.analiseCredito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnaliseCreditoApplicationTests {

	@Test
	void contextLoads() {
	}

}
